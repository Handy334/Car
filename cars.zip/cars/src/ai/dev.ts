import { config } from 'dotenv';
config();

import '@/ai/flows/recommend-cars.ts';